import pandas as pd
import zipfile
import glob
import os
from sklearn import preprocessing

path_to_zip_file="/content/drive/MyDrive/adhd-detector/data/results/zip_files/amir_adhd_adult/beta.zip"
directory_to_extract_to="/content/drive/MyDrive/adhd-detector/data/results/signals/adult_adhd/"
path_to_load="/content/drive/MyDrive/adhd-detector/data/results/signals/adult_adhd/beta/"
path_to_cluster= "/content/drive/MyDrive/adhd-detector/data/results/clusters/adult_adhd/"

with zipfile.ZipFile(path_to_zip_file, 'r') as zip_ref:
    zip_ref.extractall(directory_to_extract_to)


txt_files = glob.glob(os.path.join(path_to_load, "*.TXT"))

for f in txt_files: 
    slash=0
    i=0
    for i in range(len(f)):
      if f[i]=='/':
        slash= slash+1
      if slash==10:
        break

    f_name=f[i+1:len(f)] 
    x= f_name.split(".")
    file_name=x[0]
    # read the csv file
    df= pd.read_fwf(f, names=['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18'])
    
    df_sliced=df[:2505]
    
    #Store channels values based on brain location - Frontal, Central, Perietal, Occipitial, Temporal 
    fl=df_sliced[['0','2','3','4']]
    fr=df_sliced[['1','5','6']]
    cl=df_sliced[['8']]
    cr=df_sliced[['10']]
    pl=df_sliced[['12','13','14']]
    pr=df_sliced[['15','16']]
    ol=df_sliced[['17']]
    orr=df_sliced[['18']]
    tl=df_sliced[['11']]
    tr=df_sliced[['7']]

    # Frontal left lobe

    x = fl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    fl = pd.DataFrame(x_scaled)
    fl.columns =['0','2','3','4']
    fl['frontal_left'] = fl.mean(axis=1)
    fl=fl.drop(columns=['0','2','3','4'], axis=1)

    # Frontal right lobe
    print('Extracting features.....')
    x = fr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    fr = pd.DataFrame(x_scaled)
    fr.columns =['1','5','6']
    fr['frontal_right'] = fr.mean(axis=1)
    fr=fr.drop(columns=['1','5','6'], axis=1)

    # Central left lobe

    x = cl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    cl = pd.DataFrame(x_scaled)
    cl.columns =['8']
    cl['central_left'] = cl.mean(axis=1)
    cl=cl.drop(columns=['8'], axis=1)

    # Central right lobe

    x = cr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    cr = pd.DataFrame(x_scaled)
    cr.columns =['10']
    cr['central_right'] = cr.mean(axis=1)
    cr=cr.drop(columns=['10'], axis=1)

    # Parietal left lobe

    x = pl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    pl = pd.DataFrame(x_scaled)
    pl.columns =['12','13','14']
    pl['parietal_left'] = pl.mean(axis=1)
    pl=pl.drop(columns=['12','13','14'], axis=1)

    # Parietal right lobe

    x = pr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    pr = pd.DataFrame(x_scaled)
    pr.columns =['15','16']
    pr['perietal_right'] = pr.mean(axis=1)
    pr=pr.drop(columns=['15','16'], axis=1)

    # Occipital left lobe

    x = ol.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    ol = pd.DataFrame(x_scaled)
    ol.columns =['17']
    ol['occipitial_left'] = ol.mean(axis=1)
    ol=ol.drop(columns=['17'], axis=1)
    # Occipital right lobe
    x = orr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    orr = pd.DataFrame(x_scaled)
    orr.columns =['18']
    orr['occipitial_right'] = orr.mean(axis=1)
    orr=orr.drop(columns=['18'], axis=1)

    # temporal left lobe
    x = tl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    tl = pd.DataFrame(x_scaled)
    tl.columns =['11']
    tl['temporal_left'] = tl.mean(axis=1)
    tl=tl.drop(columns=['11'], axis=1)

    # temporal right lobe

    x = tr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    tr = pd.DataFrame(x_scaled)
    tr.columns =['7']
    tr['temporal_right'] = tr.mean(axis=1)
    tr=tr.drop(columns=['7'], axis=1)

    print('Feature extraction complete.')
    print('Final data cluster prepared')
    df_cluster = pd.concat([fl,fr,cl,cr,pl,pr,ol,orr,tl,tr], axis=1)

    #save cluster to the direcetory
    df_cluster.to_csv(path_to_cluster+file_name +'.csv', index = False)
    print('Dataset build process complete!')



