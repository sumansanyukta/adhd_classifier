import os
import glob
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from keras.utils import np_utils

  
  
# use glob to get all the csv files 
# in the folder
path_healthy="/content/drive/MyDrive/adhd-detector/data/results/clusters/HBN_healthy/"
csv_healthy = glob.glob(os.path.join(path_healthy, "*.csv"))

path_adhd="/content/drive/MyDrive/adhd-detector/data/results/clusters/HBN_adhd/"
csv_adhd = glob.glob(os.path.join(path_adhd, "*.csv"))

df = []
# loop over the list of csv files
for f,g in zip(csv_healthy,csv_adhd): 
    # read the csv file
    buffer = pd.read_csv(f)
    #buffer=buffer[:10]
    print(buffer.shape, 'Imported ', f.split("/")[-1])
    df.append(buffer)
    buffer = pd.read_csv(g)
    #buffer=buffer[:10]
    print(buffer.shape, 'Imported ', g.split("/")[-1])
    df.append(buffer)

CSV_SUBJECTS_IDS= '/content/drive/MyDrive/adhd-detector/data/subjects_id/subjects_id.csv'


CSV_SUBJECTS_GT='/content/drive/MyDrive/adhd-detector/data/subjects_id/labels_hbn.csv'

subjects_id=pd.read_csv(CSV_SUBJECTS_IDS)
#get the ground_truth value from the ground_truth table
print('Reading ground truth value...')
gv=pd.read_csv(CSV_SUBJECTS_GT, sep=';')
#print(ground_value['ground_truth'])
y1=[]

list_ids=subjects_id.id.values.tolist()
for i in list_ids:
  gv.set_index("id")
  gt_val=gv.iloc[:, 1]
  #gt_val=gt_val[each_subject]
y1.append(gt_val)


#Prepare X and Y 
#y=y.to_numpy()
X=df+df
#y=y.values.reshape(-1,1)
y=y1+y1
y = np.array(y).reshape(400,)
#X= X.reshape(253, 2505, 10, 1)




X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, shuffle=True)



