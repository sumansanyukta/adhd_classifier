# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 2020
@author: Sanyukta Suman

Utility script to delete files created during execution. Modify
main function to custom the folder files to be deleted.
"""

import os
import configparser

#read configurarion file
config = configparser.ConfigParser()
root_path= os.getcwd().replace('scripts','')
script_location = os.getcwd().replace('scripts','configuration')
config.read_file(open(script_location+'/drive/MyDrive/adhd-detector/configuration/config.cfg'))

#config variables
PATH_SIGNALS_CSV=root_path+config.get('PATH_STORE','PATH_SIGNALS_CSV')
PATH_DATA_ID_2  =root_path+config.get('PATH_STORE','PATH_DATA_ID_2')
PATH_DATA_ID_44 =root_path+config.get('PATH_STORE','PATH_DATA_ID_44')
PATH_DATA       =root_path+config.get('PATH_STORE','PATH_DATA')
PATH_RESULTS    = root_path + config.get('PATH_STORE','PATH_RESULTS')

def empty_signals_csv():
    files=[f for f in os.listdir(PATH_SIGNALS_CSV) if f.endswith('.csv')]
    for each_file in files:
        os.remove(PATH_SIGNALS_CSV+each_file)

def try_pass(functions):
    try:
        functions()
    except Exception as e: 
        print(e)
        pass

def main():
    try_pass(empty_signals_csv)

#if __name__ == "__main__":
main()