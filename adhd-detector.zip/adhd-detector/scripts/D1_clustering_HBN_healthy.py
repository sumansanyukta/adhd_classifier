import pandas as pd
import zipfile
import glob
import os
from sklearn import preprocessing

path_to_zip_file="/content/drive/MyDrive/adhd-detector/data/results/zip_files/HBN_healthy/healthy_alpha.zip"
directory_to_extract_to="/content/drive/MyDrive/adhd-detector/data/results/signals/HBN_healthy/"
path_to_load="/content/drive/MyDrive/adhd-detector/data/results/signals/HBN_healthy"
path_to_cluster="/content/drive/MyDrive/adhd-detector/data/results/clusters/HBN_healthy/"

with zipfile.ZipFile(path_to_zip_file, 'r') as zip_ref:
    zip_ref.extractall(directory_to_extract_to)
csv_files = glob.glob(os.path.join(path_to_load, "*.csv"))


for f in csv_files: 
    slash=0
    i=0
    for i in range(len(f)):
      if f[i]=='/':
        slash= slash+1
      if slash==9:
        break

    file_name=f[i+1:len(f)]

    # read the csv file
    df_final= pd.read_csv(f)
    #Store channels values based on brain location - Frontal, Central, Perietal, Occipitial, Temporal 
    fl=df_final[['22', '26', '18', '23', '27', '19','24']]
    fr=df_final[['2', '3', '4', '5', '9', '10']]
    cl=df_final[['7','13', '20','28','29','34','35','36','30','41']]
    cr=df_final[[ '112', '111', '110', '106', '105', '104', '103']]
    pl=df_final[['47', '42', '37', '31', '51', '52', '53', '54', '61']]
    pr=df_final[['80', '87', '93', '98', '97', '79', '86', '92', '78']]
    ol=df_final[['58', '59', '60', '67', '64', '65', '66', '71', '70']]
    orr=df_final[['77', '85', '91', '96', '76', '84', '90', '95', '83']]
    tl=df_final[['39', '44', '40', '45', '46', '50', '57']]
    tr=df_final[[ '109', '108', '102', '101', '100']]

      # Frontal left lobe

    x = fl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    fl = pd.DataFrame(x_scaled)
    fl.columns =['22', '26', '18', '23', '27', '19','24']
    fl['frontal_left'] = fl.mean(axis=1)
    fl=fl.drop(columns=['22', '26', '18', '23', '27', '19','24'], axis=1)

    # Frontal right lobe
    print('Extracting features.....')
    x = fr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    fr = pd.DataFrame(x_scaled)
    fr.columns =['2', '3', '4', '5', '9', '10']
    fr['frontal_right'] = fr.mean(axis=1)
    fr=fr.drop(columns=['2', '3', '4', '5', '9', '10'], axis=1)

    # Central left lobe

    x = cl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    cl = pd.DataFrame(x_scaled)
    cl.columns =['7','13', '20','28','29','34','35','36','30','41']
    cl['central_left'] = cl.mean(axis=1)
    cl=cl.drop(columns=['7','13', '20','28','29','34','35','36','30','41'], axis=1)

    # Central right lobe

    x = cr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    cr = pd.DataFrame(x_scaled)
    cr.columns =['112', '111', '110', '106', '105', '104', '103']
    cr['central_right'] = cr.mean(axis=1)
    cr=cr.drop(columns=[ '112', '111', '110', '106', '105', '104', '103'], axis=1)

    # Parietal left lobe

    x = pl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    pl = pd.DataFrame(x_scaled)
    pl.columns =['47', '42', '37', '31', '51', '52', '53', '54', '61']
    pl['parietal_left'] = pl.mean(axis=1)
    pl=pl.drop(columns=['47', '42', '37', '31', '51', '52', '53', '54', '61'], axis=1)

    # Parietal right lobe

    x = pr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    pr = pd.DataFrame(x_scaled)
    pr.columns =['80', '87', '93', '98', '97', '79', '86', '92', '78']
    pr['perietal_right'] = pr.mean(axis=1)
    pr=pr.drop(columns=['80', '87', '93', '98', '97', '79', '86', '92', '78'], axis=1)
    # Occipital left lobe

    x = ol.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    ol = pd.DataFrame(x_scaled)
    ol.columns =['58', '59', '60', '67', '64', '65', '66', '71', '70']
    ol['occipitial_left'] = ol.mean(axis=1)
    ol=ol.drop(columns=['58', '59', '60', '67', '64', '65', '66', '71', '70'], axis=1)

    # Occipital right lobe
    x = orr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    orr = pd.DataFrame(x_scaled)
    orr.columns =['77', '85', '91', '96', '76', '84', '90', '95', '83']
    orr['occipitial_right'] = orr.mean(axis=1)
    orr=orr.drop(columns=['77', '85', '91', '96', '76', '84', '90', '95', '83'], axis=1)

    # temporal left lobe
    x = tl.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    tl = pd.DataFrame(x_scaled)
    tl.columns =['39', '44', '40', '45', '46', '50', '57']
    tl['temporal_left'] = orr.mean(axis=1)
    tl=tl.drop(columns=['39', '44', '40', '45', '46', '50', '57'], axis=1)

    # temporal right lobe

    x = tr.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(x)
    tr = pd.DataFrame(x_scaled)
    tr.columns =[ '109', '108', '102', '101', '100']
    tr['temporal_right'] = orr.mean(axis=1)
    tr=tr.drop(columns=['109', '108', '102', '101', '100'], axis=1)

    df_cluster = pd.concat([fl,fr,cl,cr,pl,pr,ol,orr,tl,tr], axis=1)

    #save the build dataset in csv format
    df_cluster.to_csv(path_to_cluster+file_name, index = False)
    print('Dataset build process complete!')




