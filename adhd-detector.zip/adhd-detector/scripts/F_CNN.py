import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten, Conv2D, MaxPooling2D, AveragePooling2D, ReLU, BatchNormalization, Dropout, Activation
from tensorflow.keras.utils import to_categorical
from tensorflow.keras import layers, models
from keras.models import model_from_json
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.optimizers import RMSprop
import json
import simplejson

opt =RMSprop(learning_rate=0.0001)
#opt = SGD(learning_rate=0.001/1000)
#opt = Adadelta(learning_rate=0.001/1000)
# -- Preparatory code --
# Model configuration
batch_size = 2
no_epochs = 15


no_classes = 1
validation_split = 0.1
verbosity = 1

X_train = np.array(X_train).reshape(320, 2505, 10, 1) # np.array(X_train).reshape(253, 2505, 1, 10) 
X_test = np.array(X_test).reshape(80, 2505, 10, 1)
X_train_np = np.array(X_train)
X_test_np = np.array(X_test)
y_train_np = np.array(y_train).reshape(320,1)
y_test_np = np.array(y_test).reshape(80,1)
# Then models can be defined as following:
model = Sequential()

model.add(Conv2D(1252, (2,2), activation='elu',strides=(1,1), input_shape = X_train.shape[1:]))
model.add(keras.layers.MaxPool2D(2,2))
model.add(Activation('relu'))
BatchNormalization()
#model.add(Dropout(0.4))

model.add(keras.layers.Conv2D(512,(2,2),activation='elu', padding="same"))
model.add(keras.layers.MaxPool2D(2,1))
model.add(Activation('relu'))
BatchNormalization()
#model.add(Dropout(0.4))

model.add(keras.layers.Conv2D(128,(2,2),activation='elu', padding="same"))
model.add(keras.layers.MaxPool2D(2,1))
model.add(Activation('relu'))
BatchNormalization()
#model.add(Dropout(0.4))

model.add(keras.layers.Flatten())
model.add(keras.layers.Dense(64,activation='elu'))
model.add(keras.layers.Dense(1,activation='sigmoid', kernel_initializer='normal'))

# Compiling the CNN
model.compile(optimizer = opt, loss = 'binary_crossentropy', metrics = ['accuracy'])

model.summary()

callback=keras.callbacks.EarlyStopping(
monitor='val_loss', min_delta=1, patience=50, verbose=2, mode='auto',
baseline=0.4, restore_best_weights=True)

mcp_save = keras.callbacks.ModelCheckpoint('/content/drive/MyDrive/adhd-detector/data/results/model/model.h5', save_best_only=True, monitor='val_loss', mode='min')

history = model.fit(X_train_np,y_train_np, validation_data=(X_test_np, y_test_np),
              batch_size=batch_size,
              epochs=no_epochs,
              validation_split = 0.1,
              verbose=1,callbacks=[callback, mcp_save])

from sklearn.metrics import roc_curve, f1_score
from sklearn.metrics import roc_auc_score
pred_prob1 = model.predict(X_test_np)
# roc curve for models
fpr1, tpr1, thresh1 = roc_curve(y_test_np, pred_prob1[:,0], pos_label=1)
# roc curve for tpr = fpr 
random_probs = [0 for i in range(len(y_test_np))]
p_fpr, p_tpr, _ = roc_curve(y_test_np, random_probs, pos_label=1)

# auc scores
auc_score1 = roc_auc_score(y_test, pred_prob1[:,0])

print(auc_score1)

# evaluate the model
_, train_acc = model.evaluate(X_train_np, y_train_np, verbose=0)
_, test_acc = model.evaluate(X_test_np, y_test_np, verbose=0)
# f1 score

print('train acc',train_acc)
print('test acc',test_acc)

# matplotlib
import matplotlib.pyplot as plt
plt.style.use('seaborn')

# plot roc curves
plt.plot(fpr1, tpr1, linestyle='--',color='orange', label='CNN')
plt.plot(p_fpr, p_tpr, linestyle='--', color='blue')
# title
plt.title('ROC curve - Beta')
# x label
plt.xlabel('False Positive Rate')
# y label
plt.ylabel('True Positive rate')

plt.legend(loc='best')
plt.savefig('ROC',dpi=300)
plt.show();