from sklearn.model_selection import KFold
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten, Conv2D, MaxPooling2D, ReLU
from tensorflow.keras.losses import binary_crossentropy
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import Adam
from scipy import interp
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import roc_auc_score
from tensorflow.keras.optimizers import SGD, RMSprop

opt =RMSprop(learning_rate=0.0001)

# Model configuration
batch_size = 5
loss_function = binary_crossentropy
no_classes = 2
no_epochs = 10
verbosity = 1
num_folds = 5

# Define per-fold score containers <-- these are new
acc_per_fold = []
loss_per_fold = []
tprs = []
aucs = []
mean_fpr = np.linspace(0,1,100)
#X_train = np.array(X_train).reshape(320, 2505, 10, 1) # np.array(X_train).reshape(253, 2505, 1, 10) 
#X_test = np.array(X_test).reshape(80, 2505, 10, 1)
X_train_np = np.array(X_train)
X_test_np = np.array(X_test)
y_train_np = np.array(y_train).reshape(320,1)
y_test_np = np.array(y_test).reshape(80,1)

# Define the K-fold Cross Validator
kfold = KFold(n_splits=num_folds, shuffle=True)

# K-fold Cross Validation model evaluation
fold_no = 1
i=0
# K-fold Cross Validation model evaluation
with tf.device('/device:GPU:0'):
  for train, test in kfold.split(X_train_np, y_train_np):

    model = Sequential()
    model.add(LSTM(10, return_sequences = True, input_shape = (X_train_np.shape[1:])))
    BatchNormalization()
    model.add(keras.layers.Flatten())
    model.add(keras.layers.Dense(64,activation='elu'))
    model.add(keras.layers.Dense(32,activation='elu'))
    model.add(keras.layers.Dense(16,activation='elu'))
    model.add(keras.layers.Dense(1,activation='sigmoid', kernel_initializer='normal'))

    # Compiling the CNN
    model.compile(optimizer = opt, loss = 'binary_crossentropy', metrics = ['accuracy'])

    #model.summary()

    callback=keras.callbacks.EarlyStopping(
    monitor='val_loss', min_delta=1, patience=50, verbose=2, mode='auto',
    baseline=0.4, restore_best_weights=True)

    mcp_save = keras.callbacks.ModelCheckpoint('/content/drive/MyDrive/adhd-detector/data/results/model/model.h5', save_best_only=True, monitor='val_loss', mode='min')


    # Generate a print
    print('------------------------------------------------------------------------')
    print(f'Training for fold {fold_no} ...')

    # Fit data to model
    history = model.fit(X_train_np,y_train_np, validation_data=(X_test_np, y_test_np),
                batch_size=1,
                epochs=20,
                validation_split = 0.1,
                verbose=verbosity,callbacks=[callback])
    
    # Generate generalization metrics
    scores = model.evaluate(X_test_np, y_test_np, verbose=0)
    print(f'Score for fold {fold_no}: {model.metrics_names[0]} of {scores[0]}; {model.metrics_names[1]} of {scores[1]*100}%')
    acc_per_fold.append(scores[1] * 100)
    loss_per_fold.append(scores[0])

    # Increase fold number
    fold_no = fold_no + 1

    pred_prob1 = model.predict(X_test_np)
    # roc curve for models
    fpr1, tpr1, thresh1 = roc_curve(y_test_np, pred_prob1[:,0], pos_label=1)
    # roc curve for tpr = fpr 
    random_probs = [0 for i in range(len(y_test_np))]
    p_fpr, p_tpr, _ = roc_curve(y_test_np, random_probs, pos_label=1)

    # auc scores
    auc_score1 = roc_auc_score(y_test, pred_prob1[:,0])

    print(auc_score1)

    # evaluate the model
    _, train_acc = model.evaluate(X_train_np, y_train_np, verbose=0)
    _, test_acc = model.evaluate(X_test_np, y_test_np, verbose=0)
    # f1 score

    print('train acc',train_acc)
    print('test acc',test_acc)


    pred_prob1 = model.predict(X_test_np)
    fpr, tpr, t = roc_curve(y_test_np,pred_prob1 [:, 0])
    tprs.append(np.interp(mean_fpr, fpr, tpr))
    roc_auc = auc(fpr, tpr)
    aucs.append(roc_auc)
    plt.plot(fpr, tpr, lw=2, alpha=0.3, label='ROC fold %d (AUC = %0.2f)' % (i, roc_auc))
    i= i+1

  plt.plot([0,1],[0,1],linestyle = '--',lw = 2,color = 'black')
  mean_tpr = np.mean(tprs, axis=0)
  mean_auc = auc(mean_fpr, mean_tpr)


  plt.plot(mean_fpr, mean_tpr, color='blue',
          label=r'Mean ROC (AUC = %0.2f )' % (mean_auc),lw=2, alpha=1)

  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('ROC_GAMMA')
  plt.legend(loc="lower right")
  plt.text(0.32,0.7,'More accurate area',fontsize = 12)
  plt.text(0.63,0.4,'Less accurate area',fontsize = 12)
  plt.savefig('ROC',dpi=300)
  plt.show()

  test_loss, test_acc = model.evaluate(X_test_np,  y_test_np, verbose=2)

  # == Provide average scores ==
  print('------------------------------------------------------------------------')
  print('Score per fold')
  for i in range(0, len(acc_per_fold)):
    print('------------------------------------------------------------------------')
    print(f'> Fold {i+1} - Loss: {loss_per_fold[i]} - Accuracy: {acc_per_fold[i]}%')
  print('------------------------------------------------------------------------')
  print('Average scores for all folds:')
  print(f'> Accuracy: {np.mean(acc_per_fold)} (+- {np.std(acc_per_fold)})')
  print(f'> Loss: {np.mean(loss_per_fold)}')
  print('------------------------------------------------------------------------')


  plt.figure(figsize=(10,5))
  plt.plot(history.history['accuracy'], label='accuracy')
  plt.plot(history.history['val_accuracy'], label = 'val_accuracy')
  plt.xlabel('Epoch')
  plt.ylabel('Accuracy')
  #plt.ylim([0.5, 1])
  plt.legend(loc='lower right')



