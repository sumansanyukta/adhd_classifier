# -*- coding: utf-8 -*-
"""
Created on Wed Jun 2 2021
@author: Sanyukta Suman

Utility script to use train 1st -(Name) classfier. 

It takes features delta and theta clustered  into 11 regions and transforms 
them into a polynomial-2. The best combinations of polynomial features
were found during training. Read thesis document for more information.

Spatial_pre: Cluster 11
Feature_Ext : delta, theta power relatives
Ml_Tech : XGB -> Polynomial
"""

import os
import configparser
from OFHandlers import load_object
import pandas as pd
from mapSubjectSegment import from_map_to_df
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt


#read configurarion file
config = configparser.ConfigParser()
root_path= os.getcwd().replace('scripts','')
script_location = os.getcwd().replace('scripts','configuration')
config.read_file(open('/content/drive/MyDrive/adhd-detector/configuration/config.cfg'))

PATH_DATA_ID_2   = root_path + config.get('PATH_STORE','PATH_DATA_ID_2')
path_id2_clf     = PATH_DATA_ID_2+'ID2_classifier/'
PATH_DATA        = root_path + config.get('PATH_STORE','PATH_DATA')
PATH_RESULTS     = root_path + config.get('PATH_STORE','PATH_RESULTS')
mapper_labels    = load_object(PATH_DATA+'mapper_subject.file')
df_mapper= pd.DataFrame.from_dict(mapper_labels)

#X=i/p = Datasets_delta_theta/features.files
#y=label(o/p) = mapper_subject

#load delta and theta tensors
#df_features=load_object(PATH_DATA_ID_2+'Datasets_delta_theta/features.files')
tensor_segments_id2   = load_object(PATH_DATA_ID_2+'data_set_tensor.file')
#split the dataset into training and testing 
X_train, X_test, y_train, y_test = train_test_split(tensor_segments_id2.X, tensor_segments_id2.y, test_size=0.33, random_state=42)

print(X_train.shape)
print(X_test.shape)
print(y_train.shape)
print(y_test.shape)
print(X_train)
#let's plot our data points on 2-D graph to eyeball our dataset and see if we can manually find any relationship between the data. 
#We can create the plot with the following script
'''
plt.plot(tensor_segments_id2.X, tensor_segments_id2.y, style='o')
plt.title('input variable vs labelss')
plt.xlabel('input')
plt.ylabel('label')
plt.show()
#def xgb_train ()
#def main()
'''